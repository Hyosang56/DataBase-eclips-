/**
 * 
 */
/**
 * 
 */
module OracleCustomer0621 {
	requires java.sql;
}